/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package pk.edu.nust.seecs.gradebook.entity;
import javax.persistence.GeneratedValue;
import javax.persistence.Id;
import javax.persistence.Entity;
import javax.persistence.Column;

/**
 *
 * @author mali.bscs13seecs
 */
@Entity
public class table_name implements java.io.Serializable  {
    @Id
    @GeneratedValue
    @Column(name = "ID")
    private Integer fId;
    @Column
    private String fname;
    @Column
    private String hashes;
    
    public table_name(String fname, String hashes) {
        this.fname = fname;
        this.hashes = hashes;
    }
    
    public Integer getfID() {
        return fId;
    }

    public String getFName() {
        return fname;
    }

    public void setFName(String name) {
        this.fname = name;
    }
    public String getFhash() {
        return fname;
    }

    public void setFhash(String hash) {
        this.hashes = hash;
    }
    @Override
    public String toString() {
        return "Clo{" + "cloId=" + fId + ", name=" + fname + ", hash=" + hashes + '}';
    }
}
