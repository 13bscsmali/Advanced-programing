package pk.edu.nust.seecs.gradebook.util;

import org.hibernate.cfg.AnnotationConfiguration;
import org.hibernate.SessionFactory; 
import org.hibernate.Transaction;  
import org.hibernate.boot.registry.StandardServiceRegistryBuilder;
import org.hibernate.cfg.Configuration;  
import org.hibernate.service.ServiceRegistry;
import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.IOException;
import java.security.MessageDigest;

/**
 * Hibernate Utility class with a convenient method to get Session Factory
 * object.
 *
 * @author fahad
 */
public class HibernateUtil {

    
    
    public static void main(String[] args) throws IOException {  
            // Create the SessionFactory from standard (hibernate.cfg.xml) 
            // config file.
            Configuration cfg=new Configuration();  
		cfg.configure("hibernate.cfg.xml");//populates the data of the configuration file  
		//creating seession factory object  
		ServiceRegistry serviceRegistry = new StandardServiceRegistryBuilder().applySettings(cfg.getProperties()). build();

            SessionFactory factory=cfg.buildSessionFactory(serviceRegistry);
		//creating session object  
		Session session=factory.openSession(); 
                MessageDigest md = MessageDigest.getInstance("MD5");
                try{
               FileInputStream fis = new FileInputStream("args[1]");
               byte[] dataBytes = new byte[1024];
     
        int nread = 0; 
        while ((nread = fis.read(dataBytes)) != -1) {
          md.update(dataBytes, 0, nread);
        };
        } catch (FileNotFoundException e) {
          e.printStackTrace();
        }
        
        byte[] mdbytes = md.digest();
     
        //convert the byte to hex format method 1
        StringBuffer sb = new StringBuffer();
        for (int i = 0; i < mdbytes.length; i++) {
          sb.append(Integer.toString((mdbytes[i] & 0xff) + 0x100, 16).substring(1));
        }

        System.out.println("Digest(in hex format):: " + sb.toString());
        
        //convert the byte to hex format method 2
        StringBuffer hexString = new StringBuffer();
    	for (int i=0;i<mdbytes.length;i++) {
    		String hex=Integer.toHexString(0xff & mdbytes[i]);
   	     	if(hex.length()==1) hexString.append('0');
   	     	hexString.append(hex);
    	}
    	System.out.println("Digest(in hex format):: " + hexString.toString());
                
			//creating transaction object  
			Transaction t=session.beginTransaction();  
			table_name f1=new table_name();  
		  
			f1.setFName("");  
			f1.setFhash(hexString.toString());  
			session.persist(f1);//persisting the object  
			t.commit();//transaction is commited  
		session.close();  

       
    }
    
   
}
