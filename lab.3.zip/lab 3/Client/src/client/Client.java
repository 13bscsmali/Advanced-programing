/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package client;

/**
 *
 * @author mali.bscs13seecs
 */
import java.io.BufferedReader;
import java.io.BufferedWriter;
import java.io.InputStream;
import java.io.InputStreamReader;
import java.io.OutputStream;
import java.io.FileOutputStream;
import java.io.OutputStreamWriter;
import java.net.InetAddress;
import java.net.Socket;
import client.Storage;
import java.io.FileInputStream;
import java.io.IOException;
import java.io.ObjectInputStream;
import java.io.ObjectOutputStream;
import java.util.Scanner;
public class Client
{
 
    private static Socket socket;
     
    public static int mymenu(){
        Scanner in = new Scanner(System.in);
        System.out.println("Welcome to notes archiver");
        System.out.println("Please choose an option:");
        System.out.println("1.New User");
        System.out.println("2.Search User");
        int res =0;
        while(true)
        {
            
        res = in.nextInt();
        if(res == 1)
            return res;
        }
        //return res;
    }
    public static int mymenu2()
    {
        Scanner in = new Scanner(System.in);
        System.out.println("Do you want to add notes? Y or N");
        while(true){
        String s = in.next();
        if(s.charAt(0)=='y')
        {
            return 1;
        }
        if(s.charAt(0)=='n')
        {
            return 0;
        }
        }
    }
 
    public static void main(String args[])
    {
        Scanner in = new Scanner(System.in);
        int response = mymenu();
        if(response == 1)
        {
          
          Storage s = new Storage();
          System.out.println("Enter a username: ");
          s.username=in.nextLine();
          response = mymenu2();
          if(response == 1)
          {
              System.out.println("Enter your note: ");
              String k = in.nextLine();
              s.addnotes(k);
          }
          else
          {
              try
                {
                 String host = "localhost";
            int port = 25000;
            InetAddress address = InetAddress.getByName(host);
            socket = new Socket(address, port);
          
            //Send the message to the server
            OutputStream os = socket.getOutputStream();
            OutputStreamWriter osw = new OutputStreamWriter(os);
            BufferedWriter bw = new BufferedWriter(osw);
 
            String message = "sending";
 
            String sendMessage = message + "\n";
            bw.write(sendMessage);
            bw.flush();   
                 FileOutputStream fileOut =
                 new FileOutputStream("/tmp/storage.ser");
                 ObjectOutputStream out = new ObjectOutputStream(fileOut);
                 out.writeObject(s);
                 out.close();
                 fileOut.close();
                }catch(IOException i){
                    i.printStackTrace();
                }

          }
        }
        if(response == 2)
        {
        try
        {
            String host = "localhost";
            int port = 25000;
            InetAddress address = InetAddress.getByName(host);
            socket = new Socket(address, port);
            System.out.println("enter the user name to be searched: ");
            String username = in.nextLine();
          
            //Send the message to the server
            OutputStream os = socket.getOutputStream();
            OutputStreamWriter osw = new OutputStreamWriter(os);
            BufferedWriter bw = new BufferedWriter(osw);
 
            String message = "search";
 
            String sendMessage = message + "\n";
            bw.write(sendMessage);
            bw.flush();
            //System.out.println("Message sent to the server : "+sendMessage);
             message = username;
 
             sendMessage = message + "\n";
            bw.write(sendMessage);
            bw.flush();
            //Get the return message from the server
            InputStream is = socket.getInputStream();
            InputStreamReader isr = new InputStreamReader(is);
            BufferedReader br = new BufferedReader(isr);
            String reply = br.readLine();
            if(reply =="found")
            {
                Storage ss = null;
                try{
                FileInputStream fileIn = new FileInputStream("/Storage.ser");
                ObjectInputStream in2 = new ObjectInputStream(fileIn);
                ss = (Storage) in2.readObject();
                in2.close();
                fileIn.close();
                response = mymenu2();
                if(response == 1)
                {
                    System.out.println("Enter your note: ");
                    String k = in.nextLine();
                    ss.addnotes(k);
                }
                else
                {
                  try
                {
                     message = "sending";
                     sendMessage = message + "\n";
                    bw.write(sendMessage);
                    FileOutputStream fileOut =
                 new FileOutputStream("/tmp/storage.ser");
                 ObjectOutputStream out = new ObjectOutputStream(fileOut);
                 out.writeObject(ss);
                 out.close();
                 fileOut.close();
                }catch(IOException i){
                    i.printStackTrace();
                }  
                }
                }catch(IOException i){
                  i.printStackTrace();
                  
               
                  
               }catch(ClassNotFoundException c)
               {
                  System.out.println("class not found");
                  c.printStackTrace();
                  
               }
            }
            System.out.println("Message received from the server : " +message);
        }
        catch (Exception exception)
        {
            exception.printStackTrace();
        }
        finally
        {
            //Closing the socket
            try
            {
                socket.close();
            }
            catch(Exception e)
            {
                e.printStackTrace();
            }
        }
    }}
}
