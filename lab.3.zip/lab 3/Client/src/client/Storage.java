/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

/**
 *
 * @author mali.bscs13seecs
 */

package client;

import java.util.List;

public class Storage {
   public String username;
   private List<String> Notes;
   Storage()
   {
       username= null;
       
   }
   public void addnotes(String n){
       Notes.add(n);
   }
   public void displaynotes(){
       for(String temp : Notes)
       System.out.println(temp);
   }
   
}
