/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package server;

/**
 *
 * @author mali.bscs13seecs
 */
import java.io.BufferedReader;
import java.io.BufferedWriter;
import java.io.FileInputStream;
import java.io.FileOutputStream;
import java.io.IOException;
import java.io.InputStream;
import java.io.InputStreamReader;
import java.io.ObjectInputStream;
import java.io.ObjectOutputStream;
import java.io.OutputStream;
import java.io.OutputStreamWriter;
import java.net.ServerSocket;
import java.net.Socket;
import java.util.List;
import Server.Storage;
 
public class Server
{
 
    private static Socket socket;
 
    public static void main(String[] args)
    {
        List<Storage> s = null;
        try
        {
 
            int port = 25000;
            ServerSocket serverSocket = new ServerSocket(port);
            System.out.println("Server Started and listening to the port 25000");
            
 
            //Server is running always. This is done using this while(true) loop
            while(true)
            {
                //Reading the message from the client
                socket = serverSocket.accept();
                InputStream is = socket.getInputStream();
                InputStreamReader isr = new InputStreamReader(is);
                BufferedReader br = new BufferedReader(isr);
                OutputStream os = socket.getOutputStream();
                OutputStreamWriter osw = new OutputStreamWriter(os);
                BufferedWriter bw = new BufferedWriter(osw);
                String message1 = br.readLine();
                if(message1 == "sending")
                {
                    Storage p = null;
                    try{
                        FileInputStream fileIn = new FileInputStream("/employee.ser");
                        ObjectInputStream in = new ObjectInputStream(fileIn);
                        p = (Storage) in.readObject();
                        in.close();
                        fileIn.close();
                        s.add(p);
                        }catch(IOException i){
                            i.printStackTrace();

                         }catch(ClassNotFoundException c)
                         {
                             System.out.println("Employee class not found");
                             c.printStackTrace();

                            }

                }
                if(message1 == "search")
                {
                    
                    String message2 = br.readLine();
                    for(Storage l: s)
                    {
                       if(l.username == message2)
                       {
                           bw.write("found");
                           bw.flush();
                           FileOutputStream fileOut =
                            new FileOutputStream("/storage.ser");
                            ObjectOutputStream out = new ObjectOutputStream(fileOut);
                            out.writeObject(l);
                            out.close();
                            fileOut.close();
                       }
                    }
                    
                    
                }
                
                //System.out.println("Message received from client is "+number);
 
                //Multiplying the number by 2 and forming the return message
                String returnMessage;
               /* try
                {
                    int numberInIntFormat = Integer.parseInt(number);
                    int returnValue = numberInIntFormat*2;
                    returnMessage = String.valueOf(returnValue) + "\n";
                }
                catch(NumberFormatException e)
                {
                    //Input was not a number. Sending proper message back to client.
                    returnMessage = "Please send a proper number\n";
                }
 
                //Sending the response back to the client.
                
                bw.write(returnMessage);
                System.out.println("Message sent to the client is "+returnMessage);
                bw.flush();*/
            }
        }
        catch (Exception e)
        {
            e.printStackTrace();
        }
        finally
        {
            try
            {
                socket.close();
            }
            catch(Exception e){}
        }
    }
}
