/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package mymain;

import org.junit.After;
import org.junit.AfterClass;
import org.junit.Before;
import org.junit.BeforeClass;
import org.junit.Test;
import static org.junit.Assert.*;

/**
 *
 * @author mali.bscs13seecs
 */
public class NewClassTest {
    
    public NewClassTest() {
    }
    
    @BeforeClass
    public static void setUpClass() {
    }
    
    @AfterClass
    public static void tearDownClass() {
    }
    
    @Before
    public void setUp() {
    }
    
    @After
    public void tearDown() {
    }

    /**
     * Test of NewClass method, of class NewClass.
     */
    @Test
    public void testNewClass() {
        System.out.println("NewClass");
        NewClass instance = new NewClass();
        instance.NewClass();
        // TODO review the generated test code and remove the default call to fail.
        fail("The test case is a prototype.");
    }

    /**
     * Test of UpdateAttendance method, of class NewClass.
     */
    @Test
    public void testUpdateAttendance() {
        System.out.println("UpdateAttendance");
        String query = "";
        int expResult = 0;
        int result = NewClass.UpdateAttendance(query);
        assertEquals(expResult, result);
        // TODO review the generated test code and remove the default call to fail.
        fail("The test case is a prototype.");
    }

    /**
     * Test of UpdateCourse method, of class NewClass.
     */
    @Test
    public void testUpdateCourse() {
        System.out.println("UpdateCourse");
        String query = "";
        int expResult = 0;
        int result = NewClass.UpdateCourse(query);
        assertEquals(expResult, result);
        // TODO review the generated test code and remove the default call to fail.
        fail("The test case is a prototype.");
    }

    /**
     * Test of UpdateStudent method, of class NewClass.
     */
    @Test
    public void testUpdateStudent() {
        System.out.println("UpdateStudent");
        String query = "";
        int expResult = 0;
        int result = NewClass.UpdateStudent(query);
        assertEquals(expResult, result);
        // TODO review the generated test code and remove the default call to fail.
        fail("The test case is a prototype.");
    }

    /**
     * Test of UpdateTeacher method, of class NewClass.
     */
    @Test
    public void testUpdateTeacher() {
        System.out.println("UpdateTeacher");
        String query = "";
        int expResult = 0;
        int result = NewClass.UpdateTeacher(query);
        assertEquals(expResult, result);
        // TODO review the generated test code and remove the default call to fail.
        fail("The test case is a prototype.");
    }

    /**
     * Test of GetAttendance method, of class NewClass.
     */
    @Test
    public void testGetAttendance() {
        System.out.println("GetAttendance");
        String query = "";
        int expResult = 0;
        int result = NewClass.GetAttendance(query);
        assertEquals(expResult, result);
        // TODO review the generated test code and remove the default call to fail.
        fail("The test case is a prototype.");
    }

    /**
     * Test of GetCourse method, of class NewClass.
     */
    @Test
    public void testGetCourse() {
        System.out.println("GetCourse");
        String query = "";
        int expResult = 0;
        int result = NewClass.GetCourse(query);
        assertEquals(expResult, result);
        // TODO review the generated test code and remove the default call to fail.
        fail("The test case is a prototype.");
    }

    /**
     * Test of GetStudent method, of class NewClass.
     */
    @Test
    public void testGetStudent() {
        System.out.println("GetStudent");
        String query = "";
        int expResult = 0;
        int result = NewClass.GetStudent(query);
        assertEquals(expResult, result);
        // TODO review the generated test code and remove the default call to fail.
        fail("The test case is a prototype.");
    }

    /**
     * Test of GetTeacher method, of class NewClass.
     */
    @Test
    public void testGetTeacher() {
        System.out.println("GetTeacher");
        String query = "";
        int expResult = 0;
        int result = NewClass.GetTeacher(query);
        assertEquals(expResult, result);
        // TODO review the generated test code and remove the default call to fail.
        fail("The test case is a prototype.");
    }
    
}
