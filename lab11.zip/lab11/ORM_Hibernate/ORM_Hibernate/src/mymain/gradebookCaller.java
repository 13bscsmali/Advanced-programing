/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package mymain;
import main.gradebook.dao.CloDao;
import main.gradebook.dao.ContentDao;
import main.gradebook.dao.CourseDao;
import main.gradebook.dao.GradeDao;
import main.gradebook.dao.StudentDao;
import main.gradebook.dao.TeacherDao;

import main.gradebook.entity.Content;
import main.gradebook.entity.Course;
import main.gradebook.entity.Grade;
import main.gradebook.entity.Student;
import main.gradebook.entity.Teacher;
import main.gradebook.entity.Clo;
/**
 *
 * @author mali.bscs13seecs
 */
public class gradebookCaller {
    public static void UpdateGrade(String Query)
    {
        
    }
    public static void GetGrade(String Query)
    {
        
    }
    
}
