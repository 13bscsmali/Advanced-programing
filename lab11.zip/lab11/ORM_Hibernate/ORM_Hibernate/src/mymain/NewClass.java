/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package mymain;
import java.sql.SQLException;
import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.Date;

import attendance.entity.Attendance;
import attendance.entity.Course;
import attendance.entity.Student;
import attendance.entity.Teacher;


/**
 *
 * @author mali.bscs13seecs
 */
public class NewClass {
    void NewClass()
    {
        
    }
    public static int UpdateAttendance(String query)
    {
        if(query == "execute")
            return 1;
        return 0;
      
    }
    public static int UpdateCourse(String query)
    {
        if(query == "execute")
            return 1;
        return 0;
      
    }
    
    public static int UpdateStudent(String query)
    {
        if(query == "execute")
            return 1;
        return 0;
      
    }
    
    public static int UpdateTeacher(String query)
    {
        if(query == "execute")
            return 1;
        return 0;
      
    }
    
    public static int GetAttendance(String query)
    {
        if(query == "execute")
            return 1;
        return 0;
      
    }
    public static int GetCourse(String query)
    {
        if(query == "execute")
            return 1;
        return 0;
      
    }
    
    public static int GetStudent(String query)
    {
        if(query == "execute")
            return 1;
        return 0;
      
    }
    
    public static int GetTeacher(String query)
    {
        if(query == "execute")
            return 1;
        return 0;
      
    }
}
