package main.gradebook;
import java.sql.SQLException;
import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.Date;
import java.util.Scanner;

import mymain.NewClass;
import mymain.gradebookCaller;

/**
 * My main App. 
 * <p>
 This executes everything.
 */

public class App {

    public static void main(String[] args) {
        
        
        System.out.println("welcome to my school");
        System.out.println("Choose from menu:");
        System.out.println("1)get grades");
        System.out.println("2)get attendances");
        
        Scanner reader = new Scanner(System.in);  // Reading from System.in
        System.out.println("Choice: ");
        int n = reader.nextInt();
        
        if(n== 1)
        {
            gradebookCaller kk = new gradebookCaller();
            kk.GetGrade("query");
        }
        if(n== 2)
        {
            NewClass k = new NewClass();
            k.GetAttendance("query");
        }
        
    }

}