/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package local_spider;

/**
 *
 * @author mali.bscs13seecs
 */

import java.util.*;
public class me{

	private LinkedList<String> workQ;
        private LinkedList<Date> mdates;
	private boolean done;  
	private int size; 
        

	public me() {
		workQ = new LinkedList<String>();
                mdates = new LinkedList<Date>();
		done = false;
		size = 0;
	}

	public synchronized void add(String s) {
		workQ.add(s);
                
		size++;
		notifyAll();
	}

	public synchronized String remove() {
		String s;
		while (!done && size == 0) {
			try {
				wait();
			} catch (Exception e) {};
		}
		if (size > 0) {
			s = workQ.remove();
			size--;
			notifyAll();
		} else
			s = null;
		return s;
	}

	public synchronized void finish() {
		done = true;
		notifyAll();
	}
}
 

